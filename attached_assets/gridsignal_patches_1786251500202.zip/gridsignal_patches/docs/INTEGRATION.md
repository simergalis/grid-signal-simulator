# Integration Guide — Phase 0 and Phase 1

Three modules, tested here, to be wired into the existing implementation. Phase 0
and Phase 1 are integrated now. **Phase 2 (`swing.py`) is shipped but not to be
wired yet** — see the gate at the end.

```
core/power_balance.py   Phase 0   identity + noise floor + console gate
core/droop.py           Phase 1   bounded governor correction
core/swing.py           Phase 2   sub-tick integrator -- NOT YET WIRED
tests/test_patches.py             TC-123 .. TC-140, 33 tests
```

All three are pure: no I/O, no clock, no RNG, no imports from `core/`,
`runtime/`, or `renewable/`. A test asserts this.

Copy `core/*.py` into `SIM/core/` and the tests into the existing suite. Run the
suite as shipped before changing anything — expect **33 passed**. A failure
before you have touched a line is an environment difference worth knowing about.

---

## Phase 0 — `power_balance.py`

### 0.1 Derive the tolerance first

Nothing is gated until a noise floor exists, and it must come from a recording
that closes. `demo-baseline` is the only clean one (I1 exactly 0.0 across 11
ticks).

```python
from core.power_balance import calibrate_noise_floor
nf = calibrate_noise_floor(defects_from_demo_baseline, basis="demo-baseline")
print(nf.suggested_tolerance_mw)
```

Report the value. **Do not apply it automatically** and do not calibrate on
`demo-20mw` or `demo-pms-shortfall` — a tolerance derived from a run that
violates the identity would be larger than the defect it must catch. TC-125 pins
this.

The result becomes a new catalogue key. Propose `balance_defect_tolerance_mw` in
the `locked` section, and report the name you actually use.

### 0.2 Compute the field

`d4_balance_defect_mw` is currently identically 0.0 (#273). Locate where it is
assigned in `core/simulation_core.py` and report the line verbatim before
changing it — if it is computed by some expression that evaluates to zero rather
than being a constant, that is a different defect and I want to see it.

Then assign from:

```python
from core.power_balance import BalanceTerms, balance_defect_mw, ISLANDED, GRID_TIE

terms = BalanceTerms(
    p_generation_mw=<p_generation_mw for this tick>,
    p_demand_mw=<p_demand_mw>,
    p_unserved_mw=<p_unserved_mw or 0.0>,
    grid_exchange_mw=<grid_exchange_mw>,
    island_mode=ISLANDED if <island mode> is IslandMode.ISLANDED else GRID_TIE,
)
d4_balance_defect_mw = balance_defect_mw(terms)
```

Sign convention: **positive is surplus generation.** If the existing field is
documented anywhere with the opposite convention, stop and report rather than
negating — the harness reported the convention as *indeterminate* precisely
because the field was always zero, and guessing now would bake in the wrong one.

`p_losses_mw` defaults to 0.0. If the model represents losses anywhere, say
where; leaving them out silently would put them into the residual.

### 0.3 Gate the console

```python
from core.power_balance import gate_run
verdict = gate_run(defects_for_run, tolerance_mw=<catalogue value>)
```

On `renderable is False` the run is not presented as a normal completed run. The
UI should show the reason string and suppress derived figures — reserve margin,
N-1 firm capacity, served load — since all of them rest on the same terms that
failed to reconcile.

**How the UI surfaces this is a design decision, not yours to make.** Implement
the gate, return the verdict through the existing run-completion path, and report
what surface is available. Do not design a banner.

---

## Phase 1 — `droop.py`

### 1.1 What is being replaced

At `core/simulation_core.py:707–725`:

```python
_droop_correction_mw = sum(
    (-_f_error_hz / (t.config.droop_r * state.site.frequency_nominal_hz))
    * (t.config.rated_mw / t.config.power_factor)
    for t in _on_bus_turbines
    if t.config.droop_r > 0.0
)
_p_dispatch_droop_mw = max(0.0, min(p_dispatch_required_mw + _droop_correction_mw,
                                    _sync_ceiling_mw))
```

The droop formula is correct and unchanged. Two bounds are missing around it:
nothing limits Δf, and nothing limits a unit's contribution to its own headroom
before summing — so the fleet clamp becomes the operating point. On `demo-20mw`
that produced a reported reserve floor of 42.0 MW (35.0 full fleet + 7.0 largest
unit) against an actual demand of 6.861 MW, and generation followed to 21.2 MW.

### 1.2 Replacement

```python
from core.droop import DroopUnit, droop_correction, dispatch_requirement_mw

units = [DroopUnit(unit_id=t.unit_id, rated_mw=t.config.rated_mw,
                   output_mw=t.current_output_mw, droop_r=t.config.droop_r,
                   power_factor=t.config.power_factor,
                   msl_mw=t.config.msl_mw)
         for t in _on_bus_turbines]

result = droop_correction(
    units,
    frequency_hz=state._frequency_hz,
    frequency_nominal_hz=state.site.frequency_nominal_hz,
    governor_deadband_hz=_sp.value("governor_deadband_hz"),
    max_frequency_error_hz=_sp.value("droop_max_frequency_error_hz"),
)
_p_dispatch_droop_mw, result = dispatch_requirement_mw(
    p_dispatch_required_mw, result, _sync_ceiling_mw)
```

Confirm the attribute names for current output and MSL against the codebase and
report any that differ. `msl_mw` defaults to 0.0; if minimum stable load lives
elsewhere, say where rather than leaving the default.

### 1.3 Two catalogue keys

- `governor_deadband_hz` — the existing 0.02 Hz deadband is currently a literal
  in the expression. Report where, and whether a catalogue key already exists.
- `droop_max_frequency_error_hz` — **derived, not chosen.** DR-BAL-1 is
  resolved: compute it at config load from the site's first-stage protective
  thresholds.

  ```python
  from core.droop import max_frequency_error_from_thresholds
  clamp = max_frequency_error_from_thresholds(
      site.frequency_nominal_hz,
      [<first-stage UF setting>, <first-stage OF setting>])
  ```

  Report where the site's protective settings live in the codebase and what
  values they hold. If no first-stage settings exist anywhere, stop and report —
  the function refuses rather than defaulting, and inventing a value would put a
  literal into the one place this design has kept clear of them. Second-stage
  fast trips are not the right input.

### 1.4 Expected behaviour change: none, yet

While frequency is frozen, `_f_error_hz` is near zero and the bounded correction
equals the unbounded one. **The suite delta for Phase 1 should be zero.** If any
existing test changes, stop and report — that means frequency is not as frozen as
believed, which is itself a finding.

`fleet_ceiling_binding` on the result tells you whether `_sync_ceiling_mw` was
reached. Under the bounded correction it should be reached only during genuine
full-fleet demand. Log it; if it binds routinely, the bound is wrong.

---

## Phase 2 — `swing.py` — shipped, not wired

Included so it can be reviewed alongside the rest. **Do not wire it in this
task.** It requires Phase 1 to have landed; enabling frequency dynamics over an
unbounded droop correction gives oscillation, not fidelity.

One result from building it is worth knowing now, because it changes the Phase 2
estimate. Integrating the swing equation at the 5.0 s tick rate does not blur the
nadir — **it diverges**. For a stiff fleet the time constant is of order
milliseconds, and a single 5 s explicit step takes frequency to roughly −4.5 × 10⁶
Hz within one tick. A number that absurd is obvious, but it would be carried
forward as state.

So the module refuses: `UnstableSubstep` is raised when the substep exceeds the
system time constant, and `recommended_substep_s()` derives an appropriate one.
Phase 2 is therefore not "call the integrator once per tick" — it needs a
sub-tick loop with a substep derived per tick from the current fleet stiffness.
That is a larger change than the phase table implies and should be scoped
accordingly.

`integrate_tick` supplies no protective thresholds of its own; they are passed
in, per §28.4. It returns `NO_INERTIA` rather than a frozen frequency when no
rotating mass is on the bus, so that branch has to be handled explicitly.

---

## Do not

1. Do not wire `swing.py`. Phase 2 is gated on Phase 1 landing and on the
   sub-tick loop being scoped as its own task.
2. Do not choose a value for `droop_max_frequency_error_hz` or for the balance
   tolerance. The first is derived from site protection settings, the second
   from a clean recording. Neither is a judgement call.
3. Do not calibrate the noise floor on a recording that violates the identity.
4. Do not negate `d4_balance_defect_mw` to match an existing convention without
   reporting the convention first.
5. Do not modify `p_served_mw`, `p_unserved_mw`, or the §23 curtailment path.
   DR-2026-08-09-BALANCE decides they keep their definitions.
6. Do not fix #266–#272, #274, or #275 here.
7. Do not design the console gate's presentation. Implement the gate; report the
   surface.
8. Do not edit a shipped test to make it pass. A failing shipped test is a
   finding.

## Stop and report if

- The shipped suite does not report 33 passed before you change anything.
- `d4_balance_defect_mw` turns out to be computed by a real expression rather
  than assigned a constant.
- Any existing test changes behaviour after Phase 1.
- `demo-baseline` residuals are not clean enough to derive a tolerance from.
- The gate has no surface to report through without a UI change.
