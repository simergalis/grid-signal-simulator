# DR-2026-08-09-BALANCE — Under-delivery is a transient, not a state

**Status:** Phase 0 integrated 2026-08-09; Phase 1 dormant pending DR-BAL-1 wiring
**Supersedes:** nothing
**Related:** GS-DES-NAR-001 §2.6, DR-2026-08-08-FREQ, GS-DES-UC-001
**Defects:** #266–#272, plus #273–#275 raised here

---

## 1. What was measured

The Phase A′ invariant harness ran over 869 recorded ticks across three
recordings. The power balance identity `generation + import − served load` does
not close, in both directions:

| Recording | Ticks | I1 median | I1 worst | Shape |
|---|---|---|---|---|
| `demo-pms-shortfall` | 59 | −17.58 MW | **−18.05 MW** | Monotonic, zero reversals, every tick |
| `demo-20mw` | 799 | +0.74 MW | **+14.34 MW** | Positive on 568 of 799 ticks |
| `demo-baseline` | 11 | 0.00 MW | 0.00 MW | Clean, but an idle site |

Worst deficit: 6.45 MW generated against 24.50 MW of demand, islanded, with
`p_unserved_mw = 0.0` on every tick. The site under-delivers 74 % of its load and
reports full service.

Three corroborating results:

- **I2a residual is 3.6 × 10⁻¹⁵ MW.** `p_generation_mw` is exactly
  turbine + BESS + renewable. The imbalance is not a transport-layer aggregation
  artefact; the assets genuinely are not producing what the load consumes.
- **`d4_balance_defect_mw` is identically 0.0 on all three recordings.** The one
  field that exists to declare this condition reports nothing.
- **I3 is exactly 0.0 across all 869 ticks**, as predicted. `p_served_mw` is
  defined as `p_demand_mw − cumulative_shed`, so served + unserved ≡ demand by
  construction and the tri-field cannot detect under-delivery.

## 2. Whether the condition is physical

No. Not as a sustained state.

In an islanded system generation ≡ load instantaneously, enforced by physics
rather than by a controller. A deficit is absorbed first by rotating inertia:

    df/dt = ΔP · f₀ / (2·H·S)

For `demo-pms-shortfall` — roughly 8 MVA on bus, H = 4.0 s, ΔP = −18.05 MW —
that is about **−16.9 Hz/s**. IEEE 1547-2018 Cat I under-frequency trips at
57.0 Hz, so 3 Hz of headroom is consumed in **under 0.2 seconds**. Even with the
full 35 MW fleet synchronised it is under a second.

The recording sustains the deficit for **295 seconds** — three orders of
magnitude past physical possibility.

There is exactly one real mechanism by which served legitimately exceeds
generated: UPS or BESS discharging as *stored energy backing the load* rather
than as a generation asset, for a duration bounded by that storage. The simulator
treats BESS purely as generation, which is why the deficit neither depletes
anything nor resolves.

## 3. Decision

> **Under-delivery is a transient that resolves through protection, not a state
> the system can occupy and report.**

Consequences:

- **`p_served_mw` keeps its definition.** It is not redefined as delivered power.
  The field is correctly specified and simply never exercised, because the
  physics never produces the shed that would make it move.
- **The defect is not a reporting gap.** It is that a sustained deficit produces
  no frequency excursion, no UFLS operation, and no shed. The finding is evidence
  that the frequency and protection path is inert.
- **`d4_balance_defect_mw` becomes the computed identity residual**, and the
  console is gated on it. This documents the inconsistency rather than resolving
  it, and is explicitly an interim measure.
- **C6 is not a scenario-library gap.** No scenario produces unserved load
  because shed is unreachable, not because none was authored. Phase 4 makes C6
  satisfiable without writing a new scenario.

### Alternatives rejected

**A — Redefine `p_served_mw` as `min(demand, generation)`.** Rejected: it
encodes a quasi-steady state that cannot exist, bakes wrong physics into a field
name, and churns semantics the UI and curtailment tests already consume.

**D — Declare unmet load out of scope and gate only.** Rejected as a
destination, adopted as Phase 0. `demo-pms-shortfall` exists to be a shortfall
scenario; deleting it to avoid a defect is not a fix.

## 4. Scope boundary

This is a **simulator fidelity** change. §28.4 keeps protective functions outside
GridSignal's scope and TC-68 confirms egress carries advisories and staging
setpoints only. Nothing here gives the product a protective function. The
simulator must *model* protection — the frequency nadir is the product's central
claim and cannot be demonstrated by a model that does not produce one.

## 5. Phased remedy

| Phase | Change | Gate |
|---|---|---|
| 0 | `d4_balance_defect_mw` computes the identity; console refuses to render a run that does not close | Noise floor derived from a clean recording |
| 1 | Bound the droop correction per-unit by headroom and clamp Δf | No behaviour change while frequency is frozen |
| 2 | Residual forces the swing equation, integrated beneath the tick | A deficit produces a plausible excursion |
| 3 | BESS bidirectional and SoC-bounded; charging absorbs surplus | `demo-20mw` residual collapses |
| 4 | UFLS reachable; shed makes `p_unserved_mw` non-zero | I3 stops being a tautology in practice |
| 5 | Harness re-run across all recordings | I1 p99 within the Phase 0 noise floor |

**Phase 1 must land before Phase 2.** Enabling frequency dynamics over an
unbounded droop correction gives oscillation, not fidelity.

The harness is the acceptance test. I1 is the pass criterion; I5 and I6 catch
collateral damage to storage accounting and commitment.

## 6. New defects

- **#273 — `d4_balance_defect_mw` is identically zero.** Not computed, or
  computed as a constant. The field is wired to the wire and to persistence.
- **#274 — The swing equation does not act on the balance residual.** An 18 MW
  deficit across 295 s produces no frequency response.
- **#275 — BESS is modelled as generation only.** No charging path, so surplus
  has no sink and stored energy does not back load.

## 7. Known limits on the numbers

Carried forward, not introduced here:

- `H = 4.0 s` is annotated **"CHOSEN — no measured basis"**. Magnitudes from
  Phase 2 are directionally right and numerically unreliable.
- `_s_base_mw` assumes pf = 1.0, overstating df/dt by roughly 18 % at pf 0.85.
  The Phase 1 and 2 modules require power factor explicitly.
- Production tick rate of 5.0 s cannot resolve a 0.2 s collapse. Phase 2
  integrates beneath the tick; the tick remains the reporting cadence.

Adequate to demonstrate that a nadir exists. **Not adequate to quote a frequency
figure**, consistent with the standing rule against citing absolute frequency
numbers in demos.

## 8. Open

- **DR-BAL-1 — RESOLVED.** The Δf clamp is **derived, not chosen**: the margin
  from nominal to the tightest *first-stage* protective threshold the site
  declares. `droop.max_frequency_error_from_thresholds()` computes it and
  refuses when none are supplied — there is no default.

  Rationale: the clamp is a backstop against numerical excursion, not a physical
  limit. The physical limit is per-unit headroom, applied before summing. So the
  clamp belongs where governor action stops being the operative mechanism — past
  the first-stage threshold a machine is on a timer to disconnect, and modelling
  it as still governing models a unit that is leaving the bus. Tighter would
  distort legitimate governor response during a real excursion, which is the
  behaviour this work exists to reproduce. Second-stage fast trips are not the
  boundary.

  **Not yet wired.** Phase 1 is dormant and an unbounded fallback branch is
  currently selected when the key is null. That branch is a dual implementation
  and is to be deleted, not retained as a guard (see DR-BAL-7).

- **DR-BAL-2 — RESOLVED, first answer withdrawn.** `balance_defect_tolerance_mw`
  was set to 0.0 from `demo-baseline`. That is degenerate: 11 ticks of an idle
  site where the arithmetic cancels exactly, which is an absence of evidence
  rather than a measured floor, and it would block the first correct run whose
  MW-scale sums leave float rounding.

  Calibrate from **I2a** instead — structurally the same kind of sum, exercised
  on all 869 recorded ticks, measured p99 magnitude about 3.55e-15 MW.
  `calibrate_noise_floor` now raises `DegenerateCalibration` on an all-zero
  sample so this cannot recur silently.

- **DR-BAL-3** — The sign convention of `grid_exchange_mw` is unverified. Every
  recording is islanded, so it is identically zero and cannot be determined from
  data. Confirm against the first grid-connected recording.

- **DR-BAL-4** — I5 shows an episodic 2× discrepancy on 86 of 798 ticks
  (0.0224 MWh from ΔSoC against 0.0111 MWh from the power integral). Round-trip
  efficiency is the obvious hypothesis but 2× is far too lossy for a battery.
  Needs root cause; may interact with Phase 3.

- **DR-BAL-5 — NEW.** `p_unserved_mw` is hardcoded to 0.0 in the Phase 0 call
  site because shed is computed downstream. Wire the real field now. When Phase 4
  makes shed reachable, a hardcoded zero double-counts: served load would not be
  reduced by the shed and the identity would report a deficit that had in fact
  been resolved. Costs nothing while the value is zero.

- **DR-BAL-6 — NEW.** Phase 2 (`swing.py`) is copied into `SIM/core/` but not
  wired, correctly. It is larger than the phase table implied: integrating at the
  5.0 s tick does not blur the nadir, it **diverges** — for a stiff fleet the
  time constant is of order milliseconds and one explicit 5 s step takes
  frequency to roughly −4.5×10⁶ Hz. The module refuses via `UnstableSubstep`.
  Phase 2 therefore requires a sub-tick loop with a per-tick substep derived from
  current fleet stiffness, scoped as its own task.

- **DR-BAL-7 — NEW.** The unbounded droop fallback selected when
  `droop_max_frequency_error_hz` is null is a second code path for one behaviour.
  It is to be deleted when the derived clamp lands, not retained as a null-guard.

## 9. A recurring pattern

Three fields have now been found whose definitions make the condition they exist
to detect structurally unreachable:

| Field | Definition | Consequence |
|---|---|---|
| `p_expected_mw` | assigned from `p_renewable_mw` | degradation classifier unreachable |
| `p_served_mw` | `p_demand_mw − cumulative_shed` | under-delivery unreachable |
| `d4_balance_defect_mw` | `_d4_sum − _balance_residual_mw` | zero by algebra |

Three is not coincidence. Proposed standing review check: **for any field
intended as a diagnostic, can this quantity ever be non-zero given how it is
computed?** If the answer requires thought, it is probably an identity.
