# GridSignal patches — power balance, bounded droop, sub-tick swing

Remedy for the finding in `docs/DR-2026-08-09-BALANCE.md`: the power balance
identity does not close, by up to 18.05 MW deficit and 14.34 MW surplus, across
869 recorded ticks — and nothing on the console reports it.

| Module | Phase | Status |
|---|---|---|
| `core/power_balance.py` | 0 | Wire now |
| `core/droop.py` | 1 | Wire now; needs `droop_max_frequency_error_hz` |
| `core/swing.py` | 2 | Shipped for review; **do not wire yet** |

33 tests, TC-123 .. TC-140. `python3 -m pytest -q`

Start with `docs/INTEGRATION.md`. It gives the call sites, the two new catalogue
keys, and the do-not list.

All three modules are pure — no I/O, no clock, no RNG, no imports from the
simulator. A test asserts it.
