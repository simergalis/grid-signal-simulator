# DR-2026-08-09-BALANCE — Under-delivery is a transient, not a state

**Status:** Proposed — requires L. Spencer approval before Phase 1 begins
**Supersedes:** nothing
**Related:** GS-DES-NAR-001 §2.6, DR-2026-08-08-FREQ, GS-DES-UC-001
**Defects:** #266–#272, plus #273–#275 raised here

---

## 1. What was measured

The Phase A′ invariant harness ran over 869 recorded ticks across three
recordings. The power balance identity `generation + import − served load` does
not close, in both directions:

| Recording | Ticks | I1 median | I1 worst | Shape |
|---|---|---|---|---|
| `demo-pms-shortfall` | 59 | −17.58 MW | **−18.05 MW** | Monotonic, zero reversals, every tick |
| `demo-20mw` | 799 | +0.74 MW | **+14.34 MW** | Positive on 568 of 799 ticks |
| `demo-baseline` | 11 | 0.00 MW | 0.00 MW | Clean, but an idle site |

Worst deficit: 6.45 MW generated against 24.50 MW of demand, islanded, with
`p_unserved_mw = 0.0` on every tick. The site under-delivers 74 % of its load and
reports full service.

Three corroborating results:

- **I2a residual is 3.6 × 10⁻¹⁵ MW.** `p_generation_mw` is exactly
  turbine + BESS + renewable. The imbalance is not a transport-layer aggregation
  artefact; the assets genuinely are not producing what the load consumes.
- **`d4_balance_defect_mw` is identically 0.0 on all three recordings.** The one
  field that exists to declare this condition reports nothing.
- **I3 is exactly 0.0 across all 869 ticks**, as predicted. `p_served_mw` is
  defined as `p_demand_mw − cumulative_shed`, so served + unserved ≡ demand by
  construction and the tri-field cannot detect under-delivery.

## 2. Whether the condition is physical

No. Not as a sustained state.

In an islanded system generation ≡ load instantaneously, enforced by physics
rather than by a controller. A deficit is absorbed first by rotating inertia:

    df/dt = ΔP · f₀ / (2·H·S)

For `demo-pms-shortfall` — roughly 8 MVA on bus, H = 4.0 s, ΔP = −18.05 MW —
that is about **−16.9 Hz/s**. IEEE 1547-2018 Cat I under-frequency trips at
57.0 Hz, so 3 Hz of headroom is consumed in **under 0.2 seconds**. Even with the
full 35 MW fleet synchronised it is under a second.

The recording sustains the deficit for **295 seconds** — three orders of
magnitude past physical possibility.

There is exactly one real mechanism by which served legitimately exceeds
generated: UPS or BESS discharging as *stored energy backing the load* rather
than as a generation asset, for a duration bounded by that storage. The simulator
treats BESS purely as generation, which is why the deficit neither depletes
anything nor resolves.

## 3. Decision

> **Under-delivery is a transient that resolves through protection, not a state
> the system can occupy and report.**

Consequences:

- **`p_served_mw` keeps its definition.** It is not redefined as delivered power.
  The field is correctly specified and simply never exercised, because the
  physics never produces the shed that would make it move.
- **The defect is not a reporting gap.** It is that a sustained deficit produces
  no frequency excursion, no UFLS operation, and no shed. The finding is evidence
  that the frequency and protection path is inert.
- **`d4_balance_defect_mw` becomes the computed identity residual**, and the
  console is gated on it. This documents the inconsistency rather than resolving
  it, and is explicitly an interim measure.
- **C6 is not a scenario-library gap.** No scenario produces unserved load
  because shed is unreachable, not because none was authored. Phase 4 makes C6
  satisfiable without writing a new scenario.

### Alternatives rejected

**A — Redefine `p_served_mw` as `min(demand, generation)`.** Rejected: it
encodes a quasi-steady state that cannot exist, bakes wrong physics into a field
name, and churns semantics the UI and curtailment tests already consume.

**D — Declare unmet load out of scope and gate only.** Rejected as a
destination, adopted as Phase 0. `demo-pms-shortfall` exists to be a shortfall
scenario; deleting it to avoid a defect is not a fix.

## 4. Scope boundary

This is a **simulator fidelity** change. §28.4 keeps protective functions outside
GridSignal's scope and TC-68 confirms egress carries advisories and staging
setpoints only. Nothing here gives the product a protective function. The
simulator must *model* protection — the frequency nadir is the product's central
claim and cannot be demonstrated by a model that does not produce one.

## 5. Phased remedy

| Phase | Change | Gate |
|---|---|---|
| 0 | `d4_balance_defect_mw` computes the identity; console refuses to render a run that does not close | Noise floor derived from a clean recording |
| 1 | Bound the droop correction per-unit by headroom and clamp Δf | No behaviour change while frequency is frozen |
| 2 | Residual forces the swing equation, integrated beneath the tick | A deficit produces a plausible excursion |
| 3 | BESS bidirectional and SoC-bounded; charging absorbs surplus | `demo-20mw` residual collapses |
| 4 | UFLS reachable; shed makes `p_unserved_mw` non-zero | I3 stops being a tautology in practice |
| 5 | Harness re-run across all recordings | I1 p99 within the Phase 0 noise floor |

**Phase 1 must land before Phase 2.** Enabling frequency dynamics over an
unbounded droop correction gives oscillation, not fidelity.

The harness is the acceptance test. I1 is the pass criterion; I5 and I6 catch
collateral damage to storage accounting and commitment.

## 6. New defects

- **#273 — `d4_balance_defect_mw` is identically zero.** Not computed, or
  computed as a constant. The field is wired to the wire and to persistence.
- **#274 — The swing equation does not act on the balance residual.** An 18 MW
  deficit across 295 s produces no frequency response.
- **#275 — BESS is modelled as generation only.** No charging path, so surplus
  has no sink and stored energy does not back load.

## 7. Known limits on the numbers

Carried forward, not introduced here:

- `H = 4.0 s` is annotated **"CHOSEN — no measured basis"**. Magnitudes from
  Phase 2 are directionally right and numerically unreliable.
- `_s_base_mw` assumes pf = 1.0, overstating df/dt by roughly 18 % at pf 0.85.
  The Phase 1 and 2 modules require power factor explicitly.
- Production tick rate of 5.0 s cannot resolve a 0.2 s collapse. Phase 2
  integrates beneath the tick; the tick remains the reporting cadence.

Adequate to demonstrate that a nadir exists. **Not adequate to quote a frequency
figure**, consistent with the standing rule against citing absolute frequency
numbers in demos.

## 8. Open

- **DR-BAL-1** — `max_frequency_error_hz` has no value. A defensible basis is the
  tightest protective threshold the site declares, since past that point a
  machine trips rather than governs. Needs a decision and a catalogue key.
- **DR-BAL-2** — The Phase 0 tolerance must be derived from `demo-baseline` or a
  comparably clean recording. Calibrating on `demo-20mw` would suggest a
  tolerance larger than the 14.34 MW defect it must catch. A test pins this.
- **DR-BAL-3** — The sign convention of `grid_exchange_mw` is unverified. Every
  recording is islanded, so it is identically zero and cannot be determined from
  data. Confirm against the first grid-connected recording.
- **DR-BAL-4** — I5 shows an episodic 2× discrepancy on 86 of 798 ticks
  (0.0224 MWh from ΔSoC against 0.0111 MWh from the power integral). Round-trip
  efficiency is the obvious hypothesis but 2× is far too lossy for a battery.
  Needs root cause; may interact with Phase 3.
