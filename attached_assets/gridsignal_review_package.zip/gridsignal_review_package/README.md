# GridSignal Simulator — 60 Hz & Protection Review Package

## Contents

| File | Description |
|---|---|
| `items_1_2_gate_report.md` | Items 1 & 2: 60 Hz default + gate report (IEEE 1547-2018 threshold decisions) |
| `item_4_report.md` | Item 4: Re-characterisation — existing tests unaffected by 60 Hz default |
| `items_3_4_5_final_report.md` | **Main report** — Items 3–5: protection layer implementation + S9 test (full debugging chronicle) |
| `s9_test_trace.log` | Live pytest -v trace of the S9 scenario test (10/10 passing) |
| `full_suite_summary.log` | Full test suite run: 13 pre-existing failures / 988 passed / 16 xfailed |
| `test_s9_islanded_ramp.py` | S9 scenario test source (1080-tick islanded ramp with IEEE 1547-2018 Cat I thresholds) |
| `models.py` | SiteConfig + TickResult additions (5 threshold fields, 4 collapse fields) |
| `simulation_core.py` | Protection check block + drive-loop break on collapse |
| `run_manager.py` | Collapse field pass-through + drive-loop break |
| `scenario_factory.py` | Threshold pass-through from scenario JSON |
| `S9_islanded_ramp_protection.json` | S9 scenario spec (IEEE 1547-2018 Cat I, 60 Hz, 5×15 MW GTs, 18 MW BESS) |
| `types.ts` | Frontend TickPayload additions (4 collapse fields) |

## Key findings for reviewer

1. All five protection threshold fields use `Optional[float] = None` — None = disabled.
   This ensures zero impact on any existing 50 Hz EU/APAC test.

2. The S9 test uses H=100 s and r_asset_mw_per_s=100 (instant dispatch) — documented
   in the report with rationale. These are test-only overrides, not production defaults.

3. Pre-existing failures (13) are unchanged from before this work started. All listed in
   full_suite_summary.log. None are related to the protection layer.
