"""
GridSignal — renewable supply console.

Single-process FastAPI app: one background task ticks the simulation at 1 Hz,
the REST surface exposes state and stressor injection, and the operator console
is served as a static page from /.

Run locally:   uvicorn main:app --reload --port 8000
Run on Replit: press Run (see .replit)
"""

from __future__ import annotations

import asyncio
import contextlib
import os
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import CONFIG
from app.solar import SolarSim

STATIC_DIR = Path(__file__).parent / "static"
TICK_SECONDS = 1.0

sim = SolarSim(CONFIG)
app = FastAPI(title="GridSignal renewable supply", version="0.1.0")

_ticker: asyncio.Task | None = None


async def _tick_loop() -> None:
    """Drive the simulation on a fixed cadence.

    Deliberately a wall-clock cadence rather than a busy loop: the console is a
    demo instrument, not the control path. Nothing here is the real-time loop
    described in §18.7, and nothing here should ever become it.
    """
    while True:
        await asyncio.sleep(TICK_SECONDS)
        try:
            sim.tick()
        except Exception as exc:  # a bad tick must not kill the loop
            sim._log("Tick error: %s" % exc, "bad")


@app.on_event("startup")
async def _startup() -> None:
    global _ticker
    _ticker = asyncio.create_task(_tick_loop())


@app.on_event("shutdown")
async def _shutdown() -> None:
    if _ticker:
        _ticker.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await _ticker


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------

@app.get("/healthz")
async def healthz() -> dict:
    return {"ok": True, "tick": sim.state.t, "site": CONFIG.site_id}


@app.get("/api/solar/state")
async def solar_state() -> JSONResponse:
    return JSONResponse(sim.snapshot())


@app.get("/api/solar/config")
async def solar_config() -> dict:
    return sim.snapshot()["site"]


VALID_STRESSORS = {"cloud", "cloud_clear", "trip", "poi", "soil",
                   "spike", "turbine", "bess", "reset"}


@app.post("/api/solar/inject/{kind}")
async def inject(kind: str) -> dict:
    if kind not in VALID_STRESSORS:
        raise HTTPException(status_code=400,
                            detail="unknown stressor '%s'; valid: %s"
                                   % (kind, sorted(VALID_STRESSORS)))
    result = sim.inject(kind)
    # a cloud transient clears itself after 14 s, matching the console
    if kind == "cloud":
        asyncio.create_task(_clear_cloud_later())
    return result


async def _clear_cloud_later() -> None:
    await asyncio.sleep(14)
    sim.inject("cloud_clear")


# --------------------------------------------------------------------------
# static console
# --------------------------------------------------------------------------

@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0",
                port=int(os.environ.get("PORT", 8000)), reload=False)
