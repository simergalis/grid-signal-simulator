# NAR-001 — Invariant Harness, ChangeDetector, Trends and Narration

**Start here:**

```bash
python3 -m nar001.smoke recordings/run-xxxx.jsonl
```

That runs load → preflight → invariants → calibration and stops, because the
detector's bands must be read off a calibration curve rather than chosen. Supply
`--catalogue bands.json` afterwards to run all seven stages through to narration.

Each stage prints what it produced and **fails loudly the moment one produces
nothing**. A stage that quietly returns an empty list looks like success, and
that is how a payload-shape mismatch survives to the next stage.

Standalone analysis package. Imports nothing from `core/`, `runtime/`, `renewable/`,
`api/`, or `frontend/`. It reads recorder JSONL and writes a report.

**Sole input contract:** one JSON object per line, as `tools/invariants/record.py`
writes it —

```json
{"seq": 0, "received_wall_utc": "...", "payload": { /* verbatim wire message */ }}
```

Recorder event markers (`{"seq": N, "event": "reconnect"}`) and the
`run_complete` sentinel are recognised and counted, not treated as ticks.

## Install and run

```bash
cp -r nar001 tools/invariants/            # package
cp -r tests/*  tools/invariants/tests/    # or wherever the suite lives

# 1. preflight first — reports field availability, checks nothing
python3 -m nar001.report tools/invariants/recordings/ --preflight

# 2. full run
python3 -m nar001.report tools/invariants/recordings/ \
    --out-md reports/NAR-001_invariant_residuals.md \
    --out-jsonl reports/NAR-001_residuals.jsonl

# 3. tests
python3 -m pytest tests -q
```

A directory argument globs `*.jsonl`. Manifests are picked up automatically from
`<run>.manifest.json` beside each recording.

## What it checks

| Invariant | Identity |
|---|---|
| I1 | `p_generation_mw + grid_exchange_mw − p_demand_mw` |
| I1d | I1 residual vs the system's own `d4_balance_defect_mw` (both sign conventions) |
| I2a | `turbine + bess + renewable − p_generation_mw` |
| I2b | `p_compute_demand_mw` vs `admitted_nodes × kw_per_node` |
| I3_site / _compute / _cooling | `served + unserved − demand` |
| I4_turbine / _bess / _cooling | signed margin against nameplate |
| I5 | `ΔSoC × usable_mwh` vs ∫ BESS power (trapezoidal; rectangular in detail) |
| I6_committed / _floor | recomputed on-bus capacity and reserve floor vs reported |

## Four properties worth knowing before reading a report

**Nulls are never zero.** A field that is absent, null, or non-numeric yields
`status: not_evaluable` with the reason and field name. `kube_metrics` is null on
every tick of every recording captured so far, so I2b reports as skipped — not as
passing, and not as a zero residual.

**No tolerances, no verdicts.** `ResidualRecord` has no `passed` field and the
package defines no threshold. Tolerances must be derived from these distributions
afterwards, which is impossible if the data has already been thresholded. TC-117
asserts this by inspecting both the record schema and the checker source.

**I3 is a tautology and the report says so.** `p_served_mw` is defined as
`p_demand_mw − cumulative_shed` and `p_unserved_mw` is that shed, so the site-level
sum equals demand by construction. It cannot detect under-delivery. It is retained
as an arithmetic-consistency check. **I1 is the only load-service check here.**

**Two things are reverse-engineered rather than read.** `floor_violated` never
reaches the wire, so I6 reconstructs it from `turbine_units[]` and compares against
the reported `reserve_satisfied`; disagreements are counted. And because the demand
basis used by the commitment path isn't identifiable from the wire, I6_floor
computes the residual under both `p_demand_mw` and `net_demand_mw`, and the report
states which one reproduces the reported floor.

## Assumptions, all stated in the report

Nothing in the source system declares its units, so §1 of every report lists each
field and the unit assumed. Beyond units: on-bus means `state == 'synchronised'`;
`hot_standby` is treated as False when absent from a unit dict, and the report says
whether the key appeared at all; I5 integrates trapezoidally.

Three quantities arrive under two wire names each (`p_demand_mw` / `p_total_mw` and
friends). The ORM-attribute name is canonical, the alias is the fallback, and the
preflight flags any field where both answered — identical values are expected, and a
divergence would be a defect.

## Tests

41 tests, TC-110 through TC-117 plus loader, preflight, and three regressions.
Fixtures are synthetic and constructed to exercise the checkers, not to imitate the
real system. **Where a real recording disagrees with a fixture, the recording is
right** — several fixture values are guesses at wire shape and should be corrected
from the first real preflight rather than trusted.

The three regression tests at the end pin defects that the unit tests did not catch
and only surfaced when the report was first run against an 800-tick synthetic run:
one-sided invariants reporting the most idle asset as the extreme, shape statistics
pooling five turbines into one series and producing ~1600 spurious sign reversals,
and a tied sign-convention comparison being reported as a conclusion rather than as
indeterminate.

## Expected first-contact failures

The preflight exists because these are likely:

- a canonical field resolving on 0% of ticks — a wire-name mismatch; fix the alias
  tuple in `contracts.py:ALIASES`, not the checker
- `turbine_units[]` entries lacking `state`, `rated_mw`, or `hot_standby` — I6 and
  I4_turbine will report `not_evaluable` with the missing path named
- `kw_per_node` absent everywhere — expected; I2b stays unexercisable until a
  `kube_config` scenario runs, which is blocked on #272

None of these should require touching `checkers.py`.


---

# ChangeDetector (`nar001/detector.py`)

Deterministic change detection over consecutive tick payloads. Same input
contract, same access layer, same null discipline. 47 signals across six domains
plus per-unit expansion over `turbine_units[]`.

```python
from nar001 import ChangeDetector, required_parameters, summarise

print(required_parameters())        # 9 catalogue keys, values supplied by you
det = ChangeDetector(catalogue)     # raises MissingParameters listing all gaps
records = det.step(run_id, seq, payload)
```

## Predicates

| Kind | Behaviour |
|---|---|
| `level` | Deadbanded against the last **reported** value, not the last tick |
| `edge` | Discrete transition; never deadbanded, never suppressed |
| `rate` | Sustained d/dt past a band, after N consecutive confirmations |
| `set` | Collection membership, with added/removed |
| `availability` | A field appearing, disappearing, or going null |
| `count` | Length of a collection changed |

**Hysteresis is against the last reported value.** Comparing to the previous tick
lets a slow ramp emit nothing and a dithering signal emit forever. A ramp crossing
five deadbands emits five records; oscillation inside one deadband emits none.
(The v0.3 design text says that case "emits 1" — it should say 0.)

**RATE cannot see a single-tick step, by construction.** A step is exactly one
tick of high derivative and can never satisfy a consecutive-confirmation
predicate. That is deliberate — a single-tick derivative on a 5 s tick is
indistinguishable from noise — and LEVEL catches steps on the tick they land. A
test pins this so nobody later "fixes" RATE by dropping the confirmation count.

**Ratings are edges, not levels.** Any change to a configured rating matters,
including one smaller than a power deadband. The cooling rating moving 4.59 → 2.03
MW between two console captures would clear a 0.5 MW deadband, but 4.59 → 4.50
would not, and both are real changes.

## No literals

Every deadband, rate band, and confirmation count is a named catalogue key
supplied by the caller. Construction with a missing key raises `MissingParameters`
listing **all** gaps at once. `CANDIDATE_EXISTING_KEYS` records which existing
catalogue entries have overlapping semantics (`levelled_off_epsilon_mw` and
friends) but deliberately does not wire them — reusing or adding a key is a
configuration decision needing a DR, not a detector decision.

The values in the test catalogue are fixtures, not proposals. Real deadbands must
come from a distribution scan over recordings (NAR-2).

## Co-occurrence (`nar001/cooccurrence.py`)

Detection reports what moved; this reports what moves *together*. On the shipped
SC-20 synthetic run, four signals — `LOAD.p_demand_mw`,
`LOAD.p_compute_demand_mw`, `GEN.p_generation_mw` and `GEN.reserve_floor_mw` —
fire on the identical 52 ticks, because each is an affine function of the others.
Four lines in the feed for one event.

That matters twice over: a raw feed showing every derived signal beside its driver
is unreadable, and a `FrameFact` capped at N changes will fill with restatements of
one movement while something else is dropped. `redundant_pairs()` measures it. It
does not decide what to do about it — that is the salience question (NAR-3), and
it needs real recordings.

## Volume

On the 800-tick SC-20 synthetic run: 279 records across 86 changed ticks. Roughly
one tick in nine produces anything. A test asserts the changed-tick fraction stays
under 25%, because a feed that scrolls every tick is not a feed anyone reads.


---

# Calibration (`nar001/calibration.py`)

The detector requires nine catalogue parameters and supplies none. This scan
reports, per signal, the value and delta distributions and -- for each candidate
band -- the exact number of records the detector would emit, so a band is read off
a curve rather than chosen.

```bash
python3 -m nar001.feed recordings/ --calibrate
python3 -m nar001.feed recordings/ --catalogue bands.json --out feed.jsonl
```

Emission counts come from running the real detector, not from a separate
calculation. Counting `|delta| >= band` would be wrong: hysteresis is against the
last reported value, so a slow ramp crossing one band in ten small steps emits
once where a naive count says zero.

**Travel ratio** is net displacement over total distance travelled, and it tells
you which curve you are reading. Near 0 the signal dithers, and the curve shows a
cliff -- a band just above the dither silences it entirely, and that cliff is the
band. Near 1 the signal drifts, there is no cliff, and the band is a reporting
policy rather than a noise threshold. `still_fraction` cannot tell these apart:
an alternating signal never repeats a value either.

**A band larger than the largest step does not silence a ramp.** Hysteresis
against the last reported value means cumulative drift keeps firing; a signal is
silenced by its total range, not its step size. Easy to mis-predict when reading a
curve, so it has its own test.

# TrendAggregator (`nar001/trend.py`)

Multi-scale trend facts over a bounded sim-time history. Windows are simulated
seconds, never wall seconds and never sample counts, so a run at 10x yields the
same trends as the same run at 1x.

`update()` ingests; `facts()` reads. Facts are not emitted per tick -- every
signal at every window on every tick would produce more trend records than change
records, for a quantity that by definition changes slowly.

The step size is **the signal's own deadband**, so a movement counted as a step is
exactly one the feed would have reported, and the two stay consistent without a
second parameter.

`monotonic_fraction` is `None`, not `0.0`, when a signal did not move: zero
already means maximally non-monotonic, so a still signal reported as zero reads as
erratic. `notable()` drops flat and insufficient trends -- mechanically, not by
salience. On the SC-20 synthetic run, 41 of 57 facts were flat.

# FrameFact and template narrator

`assemble()` builds the window digest; `narrate()` writes prose with no model.

Failing invariants are **named**, never collapsed to a boolean, so the narration
can say which reading not to trust. One-sided invariants count only above their
rating -- I4 emits a signed margin, so a turbine below nameplate is the normal
case and treating it as an anomaly makes every clean frame look bad.

**Redundancy folding needs two conditions, not one.** Signals must co-fire in both
directions across the run *and* hold a stable delta ratio. Co-timing alone
collapses a busy frame to a single change, including genuinely unrelated signals.
Known limitation, pinned by a test: two unrelated signals that both ramp linearly
hold a constant ratio and will fold, so folding is reported rather than silent and
the representative is always kept.

The template satisfies the same rules a verifier would impose on a model: no
numeral it does not copy, no recommendation, no imperative -- an earlier draft
said "nothing else should be relied on" and failed its own test. It leads with the
anomaly whenever an invariant is failing, names a signal rather than its domain
(describing state of charge as "generation falling to 0.76 fraction" told the
reader the wrong thing), and caps the fault list at three with a count of the rest.

**This is the Phase C gate.** If the template alone is not useful enough to read,
a model will not rescue it.


---

# Smoke script (`nar001/smoke.py`)

Seven stages, each gating the next:

| Stage | Fails when |
|---|---|
| 1 load | no tick payloads — wrong file shape |
| 2 preflight | fewer than two core fields resolve — wrong payload shape, fix `ALIASES` |
| 3 invariants | every invariant skipped |
| 4 calibration | no signal produced a curve — nothing moved, or nothing resolved |
| 5 detection | the detector emitted nothing — bands too wide |
| 6 trends | no trend facts — no numeric signal on two or more ticks |
| 7 narration | — |

Stage 2's guard is deliberately not "some field resolved": `sim_time_seconds`
alone would satisfy that while every checker starves. It requires two of the three
core fields — the clock and both terms of the power balance.

Stage 5's guard is the failure this script mainly exists to catch. With bands too
wide, every stage "succeeds" and the feed is simply empty, which reads as a quiet
run rather than a misconfiguration.

Stage 3 prints skipped invariants as **untested, not passing**. Stage 1 flags a
recording whose manifest carries `stop_reason: dropped` as truncated, since its
tail is not evidence of anything.
